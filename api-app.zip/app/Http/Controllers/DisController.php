<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DisController extends Controller
{
    //
}
